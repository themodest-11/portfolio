"""
Builds excel/scenario_model.xlsx: a lifetime profit model of the loan
portfolio with Base / Optimistic / Pessimistic scenarios and a
rate x default-rate sensitivity grid. Every result cell is a live Excel
formula; the baseline inputs are computed from the real data by
sql/04_portfolio_kpis.sql, so the model and the reports always agree.

Usage:
    python excel/build_scenario_model.py

WHY A LIFETIME MODEL
An earlier version multiplied volume by the ANNUAL interest rate (one
year of income) but subtracted the LIFETIME default rate (losses over
the whole 3-5 year life of the loans). Mixing horizons made the base
scenario show a loss even though the portfolio is profitable in the
data. Here every line is on the same horizon, the life of the loans:

  Revenue        = Volume x (1 - PD) x Rate x Effective interest years
  Credit loss    = Volume x PD x LGD
  Cost of funds  = Volume x Funding rate x Effective interest years
  Operating cost = Volume x Opex rate x Effective interest years

  PD   = lifetime default rate by amount (closed loans)
  LGD  = unrecovered share of principal on charged-off loans, net of all
         payments received before charge-off (so defaulted loans earn no
         separate revenue line)
  Effective interest years = interest actually collected on fully paid
         loans / (principal x rate): turns the annual rate into lifetime
         income after amortisation and early repayment.

Revenue minus credit loss reconciles to the actual realized profit on
closed loans (shown on the Assumptions sheet as a check).
"""

import sqlite3
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
from etl_pipeline import load_to_sqlite, pick_source_csv, portfolio_kpis  # noqa: E402

OUT_PATH = ROOT / "excel" / "scenario_model.xlsx"

BLUE = Font(name="Arial", size=10, color="0000FF")
BLACK = Font(name="Arial", size=10, color="000000")
BOLD = Font(name="Arial", size=10, bold=True)
NOTE = Font(name="Arial", size=9, italic=True, color="595959")
TITLE = Font(name="Arial", size=13, bold=True, color="1F4E79")
HEADER_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
YELLOW = PatternFill("solid", fgColor="FFF2CC")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
USD = "$#,##0"
PCT = "0.00%"

# ------------------------------------------------------------------
# Baseline inputs from the data
# ------------------------------------------------------------------
conn = sqlite3.connect(":memory:")
load_to_sqlite(pick_source_csv(), conn)
k = portfolio_kpis(conn)
conn.close()

wb = Workbook()

# ------------------------------------------------------------------
# Sheet 1: Assumptions
# ------------------------------------------------------------------
ws = wb.active
ws.title = "Assumptions"
for col, width in zip("ABC", (40, 16, 78)):
    ws.column_dimensions[col].width = width
ws["A1"] = "Loan Portfolio Lifetime Profit Model: Assumptions"
ws["A1"].font = TITLE

for col, text in zip("ABC", ("Input", "Value", "Source / note")):
    ws[f"{col}3"] = text
    ws[f"{col}3"].font = BOLD

closed = int(k["closed_loans"])
inputs = [
    ("VOL", "Base volume, closed loans ($)", k["closed_disbursed"], USD,
     f"From data: disbursed amount of {closed:,} closed loans (Fully Paid + Charged Off)"),
    ("RATE", "Average interest rate (annual)", k["avg_rate"], PCT,
     "From data: disbursed-weighted int_rate, closed loans"),
    ("PD", "Lifetime default rate, by amount", k["default_rate_amount"], PCT,
     f"From data: Charged Off share of closed volume (by count: {k['default_rate_count']:.2%})"),
    ("LGD", "Loss given default (LGD)", k["lgd"], PCT,
     "From data: unrecovered principal on charged-off loans, net of all payments received"),
    ("YRS", "Effective interest years", k["effective_interest_years"], "0.00",
     "From data: interest collected on fully paid loans / (principal x rate)"),
    ("COF", "Cost of funds (annual)", 0.05, PCT,
     "ASSUMPTION: placeholder, replace with the bank's treasury funding rate"),
    ("OPEX", "Operating cost (annual, % of balance)", 0.02, PCT,
     "ASSUMPTION: placeholder, replace with the bank's actual cost allocation"),
]
ref = {}
row = 4
for key, label, value, fmt, note in inputs:
    ws.cell(row=row, column=1, value=label).font = BLACK
    c = ws.cell(row=row, column=2, value=float(value))
    c.font, c.fill, c.number_format = BLUE, YELLOW, fmt
    ws.cell(row=row, column=3, value=note).font = NOTE
    ref[key] = f"Assumptions!$B${row}"
    row += 1

# Reconciliation and break-even
row += 1
ws.cell(row=row, column=1, value="Check against the data").font = BOLD
row += 1
V, R, PD, LGD, Y, COF, OPEX = (ref[x] for x in ("VOL", "RATE", "PD", "LGD", "YRS", "COF", "OPEX"))
checks = [
    ("Model: revenue minus credit loss ($)",
     f"={V}*(1-{PD})*{R}*{Y}-{V}*{PD}*{LGD}", USD,
     "Model result before funding and operating costs"),
    ("Actual: realized profit on closed loans ($)",
     float(k["realized_profit_closed"]), USD,
     "From data: sum(total_payment - loan_amount), closed loans"),
    ("Difference (model vs actual)",
     f"=B{row}/B{row + 1}-1", PCT,
     "Small gap = the model reproduces the portfolio's actual economics"),
]
for label, value, fmt, note in checks:
    ws.cell(row=row, column=1, value=label).font = BLACK
    c = ws.cell(row=row, column=2, value=value)
    c.font, c.number_format = BLACK, fmt
    ws.cell(row=row, column=3, value=note).font = NOTE
    row += 1

row += 1
ws.cell(row=row, column=1, value="Break-even cost of funds (annual)").font = BOLD
c = ws.cell(row=row, column=2,
            value=f"=({V}*(1-{PD})*{R}*{Y}-{V}*{PD}*{LGD}-{V}*{OPEX}*{Y})/({V}*{Y})")
c.font, c.number_format = BOLD, PCT
ws.cell(row=row, column=3,
        value="Highest funding rate at which the portfolio still breaks even, "
              "given the opex assumption").font = NOTE

row += 2
ws.cell(row=row, column=1,
        value="Yellow = editable input. All other numbers are formulas.").font = NOTE

# ------------------------------------------------------------------
# Sheet 2: Scenarios
# ------------------------------------------------------------------
ws2 = wb.create_sheet("Scenarios")
headers = [
    "Scenario", "Volume change", "Rate change (pp)", "Default rate change (pp)",
    "Volume ($)", "Rate", "Default rate", "Interest revenue ($)", "Credit loss ($)",
    "Cost of funds ($)", "Operating cost ($)", "Net profit ($)",
    "Net margin, lifetime", "Net margin, per year",
]
for i, h in enumerate(headers, start=1):
    c = ws2.cell(row=1, column=i, value=h)
    c.font, c.fill = HEADER_FONT, HEADER_FILL
    c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    ws2.column_dimensions[get_column_letter(i)].width = 15
ws2.row_dimensions[1].height = 42

scenarios = [
    ("Base", 0.00, 0.000, 0.000),
    ("Optimistic", 0.10, 0.005, -0.020),   # better risk, slight repricing up
    ("Pessimistic", -0.10, -0.005, 0.030),  # worse risk, price pressure
]
for i, (name, dvol, drate, dpd) in enumerate(scenarios, start=2):
    ws2.cell(row=i, column=1, value=name).font = BOLD
    for col, val, fmt in ((2, dvol, "0.0%"), (3, drate, PCT), (4, dpd, PCT)):
        c = ws2.cell(row=i, column=col, value=val)
        c.font, c.fill, c.number_format = BLUE, YELLOW, fmt
    formulas = [
        (5, f"={V}*(1+B{i})", USD),
        (6, f"={R}+C{i}", PCT),
        (7, f"={PD}+D{i}", PCT),
        (8, f"=E{i}*(1-G{i})*F{i}*{Y}", USD),
        (9, f"=E{i}*G{i}*{LGD}", USD),
        (10, f"=E{i}*{COF}*{Y}", USD),
        (11, f"=E{i}*{OPEX}*{Y}", USD),
        (12, f"=H{i}-I{i}-J{i}-K{i}", USD),
        (13, f"=L{i}/E{i}", PCT),
        (14, f"=M{i}/{Y}", PCT),
    ]
    for col, formula, fmt in formulas:
        c = ws2.cell(row=i, column=col, value=formula)
        c.font, c.number_format = (BOLD if col == 12 else BLACK), fmt
    for col in range(1, len(headers) + 1):
        ws2.cell(row=i, column=col).border = BORDER
ws2.freeze_panes = "B2"
ws2.cell(row=6, column=1,
         value="Lifetime model: all lines cover the full life of the loans. "
               "Net margin per year = lifetime margin / effective interest years.").font = NOTE

# ------------------------------------------------------------------
# Sheet 3: Sensitivity grid, default rate (rows) x interest rate (columns)
# ------------------------------------------------------------------
ws3 = wb.create_sheet("Sensitivity_Grid")
ws3["A1"] = "Net profit ($): default rate change (rows) x interest rate change (columns)"
ws3["A1"].font = BOLD
ws3["A2"] = "Volume change held at:"
ws3["B2"] = 0.0
ws3["B2"].font, ws3["B2"].fill, ws3["B2"].number_format = BLUE, YELLOW, "0.0%"
ws3["A3"] = "Read across a row to see how much rate increase offsets a rise in defaults."
ws3["A3"].font = NOTE

pd_changes = [-0.04, -0.02, 0.00, 0.02, 0.04]
rate_changes = [-0.02, -0.01, 0.00, 0.01, 0.02]
hdr = 5
ws3.cell(row=hdr, column=1, value="Default change \\ Rate change").font = BOLD
ws3.column_dimensions["A"].width = 30
for j, rc in enumerate(rate_changes, start=2):
    c = ws3.cell(row=hdr, column=j, value=rc)
    c.font, c.number_format = BOLD, PCT
    ws3.column_dimensions[get_column_letter(j)].width = 15
for i, dc in enumerate(pd_changes, start=hdr + 1):
    c = ws3.cell(row=i, column=1, value=dc)
    c.font, c.number_format = BOLD, PCT
    for j in range(2, 2 + len(rate_changes)):
        col = get_column_letter(j)
        vol = f"({V}*(1+$B$2))"
        rate = f"({R}+{col}${hdr})"
        pdv = f"({PD}+$A{i})"
        formula = (f"={vol}*(1-{pdv})*{rate}*{Y}-{vol}*{pdv}*{LGD}"
                   f"-{vol}*{COF}*{Y}-{vol}*{OPEX}*{Y}")
        c = ws3.cell(row=i, column=j, value=formula)
        c.font, c.number_format, c.border = BLACK, USD, BORDER

wb.save(OUT_PATH)
print(f"Saved {OUT_PATH}")
