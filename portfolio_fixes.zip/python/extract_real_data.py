"""
Extracts the loan records from the original Kaggle workbook
(Bank_Loan_Analysis_Project.xlsx, sheet 'Merge', the raw Finance1 +
Finance2 join before any dashboard or pivot work) and writes a clean
data/financial_loan.csv with the column names used in sql/ and python/.

Usage:
    python python/extract_real_data.py path/to/Bank_Loan_Analysis_Project.xlsx

Only needed to rebuild data/financial_loan.csv; the CSV is already in the repo.
"""

import argparse
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "data" / "financial_loan.csv"

RENAME = {
    "loan_amnt": "loan_amount",
    "annual_inc": "annual_income",
    "issue_d": "issue_date",
    "addr_state": "address_state",
    "total_pymnt": "total_payment",
    "last_pymnt_d": "last_payment_date",
    "last_pymnt_amnt": "last_payment_amount",
    "last_credit_pull_d": "last_credit_pull_date",
}

KEEP = [
    "id", "member_id", "issue_date", "loan_amount", "term", "int_rate",
    "installment", "grade", "sub_grade", "emp_length", "home_ownership",
    "annual_income", "verification_status", "loan_status", "purpose",
    "address_state", "dti", "total_acc", "total_payment",
    "last_payment_date", "last_payment_amount",
]


def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("source_xlsx", type=Path, help="path to Bank_Loan_Analysis_Project.xlsx")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT, help="output CSV path")
    args = parser.parse_args()

    df = pd.read_excel(args.source_xlsx, sheet_name="Merge")
    df.columns = [c.replace("Finance2.", "") for c in df.columns]  # prefix from the original merge
    df = df.rename(columns=RENAME)[KEEP].copy()

    # int_rate is already a fraction (0.1189 = 11.89%), no conversion needed
    df["term"] = df["term"].str.strip()
    df["issue_date"] = pd.to_datetime(df["issue_date"]).dt.date
    df["last_payment_date"] = pd.to_datetime(df["last_payment_date"]).dt.date

    args.out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} rows, {len(df.columns)} columns -> {args.out}")


if __name__ == "__main__":
    main()
