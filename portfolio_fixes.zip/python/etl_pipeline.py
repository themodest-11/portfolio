"""
Requirement 4: Automation.

Loads the raw loan export into SQLite, runs the reporting SQL (sql/02-04)
and writes the results to one Excel workbook, one sheet per report,
instead of rebuilding it by hand in Excel every month.

Usage:
    python python/etl_pipeline.py

Uses data/financial_loan.csv (the real Kaggle export) and falls back to
data/sample_loans.csv (synthetic demo data) if the real file is missing.
"""

import re
import sqlite3
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
SQL_DIR = ROOT / "sql"
DB_PATH = ROOT / "loans.db"
OUT_PATH = ROOT / "reports" / "bank_loan_reports.xlsx"


def pick_source_csv() -> Path:
    real = DATA_DIR / "financial_loan.csv"
    sample = DATA_DIR / "sample_loans.csv"
    if real.exists():
        print(f"Using real dataset: {real.name}")
        return real
    if sample.exists():
        print(f"Real dataset not found, using synthetic demo data: {sample.name}")
        return sample
    sys.exit("No CSV found in data/. Run generate_sample_data.py or add financial_loan.csv.")


def load_to_sqlite(csv_path: Path, conn: sqlite3.Connection) -> None:
    conn.executescript((SQL_DIR / "01_schema_and_load.sql").read_text())
    df = pd.read_csv(csv_path)
    df["term"] = df["term"].str.strip()  # source has ' 36 months' with a leading space
    df.to_sql("loans", conn, if_exists="append", index=False)
    print(f"Loaded {len(df):,} rows into loans")


def split_statements(sql_text: str) -> list[str]:
    """Remove '--' comments, then split on ';'. Comments are removed first
    so a ';' inside a comment can never break a statement in two."""
    no_comments = re.sub(r"--[^\n]*", "", sql_text)
    return [s.strip() for s in no_comments.split(";") if s.strip()]


def run_report(sql_path: Path, conn: sqlite3.Connection) -> list[pd.DataFrame]:
    """Runs every statement in the file and returns the result of each
    SELECT, in order."""
    results = []
    for stmt in split_statements(sql_path.read_text()):
        cur = conn.execute(stmt)
        if cur.description:  # statement returned rows
            cols = [c[0] for c in cur.description]
            results.append(pd.DataFrame(cur.fetchall(), columns=cols))
    return results


def portfolio_kpis(conn: sqlite3.Connection) -> dict:
    """One-row KPI table from sql/04 as a dict (also used by the Excel model)."""
    return run_report(SQL_DIR / "04_portfolio_kpis.sql", conn)[0].iloc[0].to_dict()


def main():
    DATA_DIR.mkdir(exist_ok=True)
    (ROOT / "reports").mkdir(exist_ok=True)

    csv_path = pick_source_csv()

    if DB_PATH.exists():
        DB_PATH.unlink()
    conn = sqlite3.connect(DB_PATH)
    load_to_sqlite(csv_path, conn)

    kpis = run_report(SQL_DIR / "04_portfolio_kpis.sql", conn)[0]
    monthly = run_report(SQL_DIR / "02_management_reporting.sql", conn)[-1]
    by_purpose_grade, by_term_region = run_report(SQL_DIR / "03_profitability_by_segment.sql", conn)

    with pd.ExcelWriter(OUT_PATH, engine="openpyxl") as writer:
        kpis.T.rename(columns={0: "value"}).to_excel(writer, sheet_name="Portfolio_KPIs")
        monthly.to_excel(writer, sheet_name="Monthly_Plan_vs_Fact", index=False)
        by_purpose_grade.to_excel(writer, sheet_name="Profitability_Purpose_Grade", index=False)
        by_term_region.to_excel(writer, sheet_name="Profitability_Term_Region", index=False)

    conn.close()

    loss = by_purpose_grade[by_purpose_grade["segment_class"] == "LOSS"]
    print(f"Loss-making segments (purpose x grade): {len(loss)}, "
          f"total loss {loss['total_profit'].sum():,.0f}")
    print(f"Reports written to {OUT_PATH}")


if __name__ == "__main__":
    main()
