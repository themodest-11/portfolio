-- ============================================================
-- Portfolio KPIs (one row). Also the single source of the baseline
-- inputs for excel/scenario_model.xlsx, so the model and the reports
-- always use the same numbers.
--
-- Definitions (closed loans = Fully Paid + Charged Off):
--   default_rate_count   share of closed loans that were charged off
--   default_rate_amount  same, weighted by disbursed amount
--   lgd                  share of disbursed principal on charged-off loans
--                        that was never recovered:
--                        sum(max(loan_amount - total_payment, 0)) / sum(loan_amount)
--                        (net of ALL payments received before charge-off)
--   avg_rate             disbursed-weighted average interest rate
--   effective_interest_years
--                        interest actually collected on fully paid loans
--                        / (principal x rate). How many "years of full-balance
--                        interest" a dollar earns once amortisation and early
--                        repayment are taken into account. Converts the
--                        annual rate into a lifetime figure for the model.
-- ============================================================

select
    count(*)                                                          as total_loans,
    sum(case when loan_status = 'Current' then 1 else 0 end)          as current_loans,
    sum(case when loan_status <> 'Current' then 1 else 0 end)         as closed_loans,
    sum(case when loan_status <> 'Current' then loan_amount else 0 end)
                                                                      as closed_disbursed,
    round(
        sum(case when loan_status = 'Charged Off' then 1.0 else 0 end)
        / sum(case when loan_status <> 'Current' then 1 else 0 end), 4)
                                                                      as default_rate_count,
    round(
        sum(case when loan_status = 'Charged Off' then loan_amount else 0 end) * 1.0
        / sum(case when loan_status <> 'Current' then loan_amount else 0 end), 4)
                                                                      as default_rate_amount,
    round(
        sum(case when loan_status = 'Charged Off'
                 then max(loan_amount - total_payment, 0) else 0 end) * 1.0
        / sum(case when loan_status = 'Charged Off' then loan_amount else 0 end), 4)
                                                                      as lgd,
    round(
        sum(case when loan_status <> 'Current' then loan_amount * int_rate else 0 end)
        / sum(case when loan_status <> 'Current' then loan_amount else 0 end), 4)
                                                                      as avg_rate,
    round(
        sum(case when loan_status = 'Fully Paid' then total_payment - loan_amount else 0 end)
        / sum(case when loan_status = 'Fully Paid' then loan_amount * int_rate else 0 end), 4)
                                                                      as effective_interest_years,
    round(sum(case when loan_status <> 'Current' then total_payment - loan_amount else 0 end), 0)
                                                                      as realized_profit_closed
from loans;
