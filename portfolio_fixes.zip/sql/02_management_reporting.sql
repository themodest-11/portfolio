-- ============================================================
-- Requirement 1: Управленческая отчётность
-- Monthly issued volume, month-over-month dynamics, plan vs fact.
--
-- PLAN: the dataset has no real targets, so a plan is built the way a
-- first draft of monthly targets is often set:
--     plan(month) = average issued volume of the 3 previous months
--                   x (1 + target growth)
-- Target growth is 5% (set below). The first 3 months have no history
-- and get no plan (NULL) instead of a fake one. Replace loan_plan with
-- the bank's real targets when available.
--
-- PAYMENTS: the dataset has one cumulative payment snapshot per loan
-- (total_payment), not a monthly payment ledger. So the column
-- cohort_payments_to_date is "everything paid so far on loans issued
-- in that month" (a cohort view), NOT cash received during that month.
-- ============================================================

drop table if exists loan_plan;
create table loan_plan (
    plan_month   text primary key,   -- 'YYYY-MM'
    plan_amount  numeric             -- target issued volume for the month
);

insert into loan_plan (plan_month, plan_amount)
select plan_month, plan_amount
from (
    select
        strftime('%Y-%m', issue_date) as plan_month,
        avg(sum(loan_amount)) over (
            order by strftime('%Y-%m', issue_date)
            rows between 3 preceding and 1 preceding
        ) * 1.05                      as plan_amount,   -- +5% vs trailing 3-month average
        count(*) over (
            order by strftime('%Y-%m', issue_date)
            rows between 3 preceding and 1 preceding
        )                             as months_of_history
    from loans
    group by 1
)
where months_of_history = 3;

with monthly as (
    select
        strftime('%Y-%m', issue_date) as report_month,
        count(*)                      as loans_count,
        sum(loan_amount)              as issued_amount,
        sum(total_payment)            as cohort_payments_to_date
    from loans
    group by 1
),
with_dynamics as (
    select
        report_month,
        loans_count,
        issued_amount,
        cohort_payments_to_date,
        round(
            (issued_amount - lag(issued_amount) over (order by report_month))
            * 1.0 / nullif(lag(issued_amount) over (order by report_month), 0),
            4
        ) as mom_growth
    from monthly
)
select
    d.report_month,
    d.loans_count,
    d.issued_amount,
    d.mom_growth,
    p.plan_amount,
    round(d.issued_amount * 1.0 / nullif(p.plan_amount, 0), 4) as plan_completion,
    d.issued_amount - p.plan_amount                            as plan_gap,
    d.cohort_payments_to_date
from with_dynamics d
left join loan_plan p
    on p.plan_month = d.report_month
order by d.report_month;
