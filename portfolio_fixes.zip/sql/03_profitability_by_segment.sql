-- ============================================================
-- Requirement 2: Рентабельность сегментов
-- Profitability by loan type (purpose x grade) and by term x region.
--
-- METHOD NOTES
-- 1. Only CLOSED loans (Fully Paid, Charged Off) are used. A 'Current'
--    loan is still being repaid, so total_payment - loan_amount is not
--    its final result and would distort both profit and default rate.
-- 2. realized_profit = total_payment - loan_amount (everything received
--    minus what was disbursed). Negative for most Charged Off loans.
-- 3. Margin is volume-weighted: sum(profit) / sum(disbursed), so a
--    segment's margin is not skewed by many tiny loans.
-- 4. Default rate is shown both by count and by amount.
-- 5. Segments are classified as:
--      LOSS - the segment loses money in total (shown separately: these
--             are the first candidates for repricing or tighter rules);
--      A/B/C - ABC among PROFITABLE segments by cumulative share of the
--             positive profit (A = up to 80%, B = up to 95%, C = rest).
--    Running ABC over a total that mixes profits and losses would push
--    the cumulative share above 100% and hide the loss-making segments.
-- ============================================================

with closed as (
    select *
    from loans
    where loan_status in ('Fully Paid', 'Charged Off')
),
by_purpose_grade as (
    select
        purpose,
        grade,
        count(*)                                                    as loans_count,
        sum(loan_amount)                                            as total_disbursed,
        sum(total_payment - loan_amount)                            as total_profit,
        round(sum(total_payment - loan_amount) * 1.0
              / nullif(sum(loan_amount), 0), 4)                     as margin,
        round(avg(case when loan_status = 'Charged Off' then 1.0 else 0 end), 4)
                                                                    as default_rate_count,
        round(sum(case when loan_status = 'Charged Off' then loan_amount else 0 end) * 1.0
              / nullif(sum(loan_amount), 0), 4)                     as default_rate_amount
    from closed
    group by purpose, grade
),
ranked as (
    select
        *,
        case when total_profit > 0 then
            sum(case when total_profit > 0 then total_profit else 0 end)
                over (order by total_profit desc
                      rows between unbounded preceding and current row)
            * 1.0
            / sum(case when total_profit > 0 then total_profit else 0 end) over ()
        end as cum_share_of_profit
    from by_purpose_grade
)
select
    purpose,
    grade,
    loans_count,
    total_disbursed,
    total_profit,
    margin,
    default_rate_count,
    default_rate_amount,
    round(cum_share_of_profit, 4) as cum_share_of_profit,
    case
        when total_profit <= 0          then 'LOSS'
        when cum_share_of_profit <= 0.80 then 'A'
        when cum_share_of_profit <= 0.95 then 'B'
        else 'C'
    end as segment_class
from ranked
order by total_profit desc;

-- Same idea, sliced by term and region. Segments with fewer than 30
-- closed loans are dropped: their default rate and margin are noise.
select
    trim(term)                                                     as term,
    address_state,
    count(*)                                                       as loans_count,
    sum(loan_amount)                                               as total_disbursed,
    sum(total_payment - loan_amount)                               as total_profit,
    round(sum(total_payment - loan_amount) * 1.0
          / nullif(sum(loan_amount), 0), 4)                        as margin,
    round(avg(case when loan_status = 'Charged Off' then 1.0 else 0 end), 4)
                                                                   as default_rate_count
from loans
where loan_status in ('Fully Paid', 'Charged Off')
group by trim(term), address_state
having count(*) >= 30
order by total_profit desc;
