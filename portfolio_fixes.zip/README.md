# Bank Loan Portfolio Analysis

A self-contained SQL + Python + Excel project on the Kaggle
["Bank Loan Analysis Project"](https://www.kaggle.com/datasets/sanjanamurthy392/bank-loan-analysis-project)
dataset (39,717 US consumer loans issued 2007–2011, amounts in USD),
structured around four tasks a bank's credit or data analyst is asked to do:

| # | Task | Where |
| --- | --- | --- |
| 1 | **Управленческая отчётность**: monthly issued volume, dynamics, plan vs fact | [`sql/02_management_reporting.sql`](sql/02_management_reporting.sql) |
| 2 | **Рентабельность сегментов**: profit, margin and default rate by loan type, grade, term and region | [`sql/03_profitability_by_segment.sql`](sql/03_profitability_by_segment.sql) |
| 3 | **Сценарная модель в Excel**: lifetime profit vs rate, volume and default rate | [`excel/scenario_model.xlsx`](excel/scenario_model.xlsx) |
| 4 | **Автоматизация**: one command rebuilds every report from the raw export | [`python/etl_pipeline.py`](python/etl_pipeline.py) |

Portfolio KPIs used by both the reports and the model come from one query:
[`sql/04_portfolio_kpis.sql`](sql/04_portfolio_kpis.sql).

## Key findings

- **Portfolio quality.** Of 38,577 closed loans, 14.6% were charged off by
  count, **16.0% by amount**. On charged-off loans **45.2%** of principal was
  never recovered (LGD, net of all payments received before charge-off).
- **The portfolio is profitable before funding costs.** Closed loans
  returned **$31.6M** over disbursed principal (+7.4%).
- **Loss-making segments are concentrated.** 16 of 98 purpose × grade
  segments lose money (−$0.89M in total). **`small_business` alone accounts
  for about 92% of that loss**: every grade from B to G is loss-making, with
  defaults of 28–43% by amount. These are the first candidates for repricing
  or tighter approval rules.
- **Funding cost decides the final result.** The model reproduces actual
  realized profit within 2.4%. At the placeholder funding cost (5%) and opex
  (2%) the base scenario is slightly negative; the portfolio breaks even at a
  funding cost of about **3.5% a year**.

## About the data

`data/financial_loan.csv` is the real dataset (39,717 loans), extracted from
the `Merge` sheet of the original Kaggle workbook with
[`python/extract_real_data.py`](python/extract_real_data.py) and renamed to the
column names used throughout `sql/` and `python/`.

`data/sample_loans.csv` is a small synthetic fallback (1,200 rows, fixed seed,
[`python/generate_sample_data.py`](python/generate_sample_data.py)) so the
pipeline still runs if the real file is removed. The pipeline always prefers
the real file.

The Kaggle workbook is someone else's finished dashboard project; this repo
reuses only its raw loan records and builds the reporting, profitability,
model and automation layers independently.

## Project structure

```
data/
  financial_loan.csv              real data, 39,717 loans
  sample_loans.csv                synthetic fallback
sql/
  01_schema_and_load.sql          table schema
  02_management_reporting.sql     monthly issued volume, dynamics, plan vs fact
  03_profitability_by_segment.sql segment profit, margin, default rate, LOSS/A/B/C
  04_portfolio_kpis.sql           portfolio KPIs and model inputs
python/
  etl_pipeline.py                 CSV -> SQLite -> SQL -> Excel report
  extract_real_data.py            rebuilds financial_loan.csv from the Kaggle workbook
  generate_sample_data.py         builds the synthetic fallback
excel/
  build_scenario_model.py         builds the model (openpyxl, formulas only)
  scenario_model.xlsx             lifetime profit model
reports/
  bank_loan_reports.xlsx          output of the pipeline
```

## How to run

```bash
pip install pandas openpyxl
python python/etl_pipeline.py          # writes reports/bank_loan_reports.xlsx
python excel/build_scenario_model.py   # writes excel/scenario_model.xlsx
```

`reports/bank_loan_reports.xlsx` has four sheets: portfolio KPIs, monthly
plan vs fact, profitability by purpose × grade, profitability by term × region.

## 1. Management reporting

Issued volume and loan count by month, month-over-month growth with `LAG`,
and plan vs fact. The data has no real targets, so the plan is a typical
first-draft target: **the average of the previous 3 months + 5%**. The first
three months have no plan rather than a fabricated one. Replace `loan_plan`
with real targets when available.

## 2. Segment profitability

- Only **closed** loans (Fully Paid, Charged Off) are used. A `Current` loan
  is still being repaid, so its payments-minus-principal is not its final
  result and would distort both profit and default rate.
- Margin is **volume-weighted** (`sum(profit) / sum(disbursed)`), so many
  small loans do not skew a segment.
- Default rate is shown **by count and by amount**.
- Segments are classified as **LOSS** (loses money in total) or **A / B / C**
  among profitable segments by cumulative share of profit (80% / 95%).
  Loss-making segments are kept out of the ABC ranking: mixing them in pushes
  the cumulative share above 100% and hides them in class C.
- The term × region view drops segments with fewer than 30 closed loans.

## 3. Excel scenario model

All result cells are live formulas; the baseline inputs come from
`sql/04_portfolio_kpis.sql`. Every line is on **the same horizon, the life of
the loans**:

| Line | Formula |
| --- | --- |
| Interest revenue | Volume × (1 − PD) × Rate × Effective interest years |
| Credit loss | Volume × PD × LGD |
| Cost of funds | Volume × Funding rate × Effective interest years |
| Operating cost | Volume × Opex rate × Effective interest years |

- **PD**: lifetime default rate by amount. **LGD**: unrecovered share of
  principal on charged-off loans, net of all payments, so defaulted loans
  have no separate revenue line.
- **Effective interest years** (1.39): interest actually collected on fully
  paid loans ÷ (principal × rate). It converts the annual rate into lifetime
  income after amortisation and early repayment; loans with a 3–5 year term
  earn roughly 1.4 years of full-balance interest.
- The `Assumptions` sheet checks the model against the data (revenue minus
  credit loss vs actual realized profit) and shows the **break-even funding
  cost**.
- `Scenarios`: Base / Optimistic / Pessimistic, driven by volume, rate and
  default rate. `Sensitivity_Grid`: net profit for default-rate change ×
  rate change, showing how much repricing offsets higher defaults.

## 4. Automation

`python/etl_pipeline.py` replaces the monthly "load CSV, drag formulas, copy
into a new tab" routine: it loads the raw export into SQLite, runs the SQL and
writes a ready-to-share Excel workbook in seconds.

## Limitations

- **Funding cost (5%) and opex (2%) are placeholders**, marked in yellow on
  the `Assumptions` sheet. The sign of the final result depends on them,
  which is why the model reports the break-even funding cost.
- The dataset has one cumulative payment snapshot per loan, not a monthly
  payment ledger, so the monthly report shows payments to date per issue-month
  cohort, not cash received in that month, and no DPD buckets or vintage
  curves can be built from it.
- US consumer-lending data from 2007–2011: the method transfers to other
  portfolios, the specific rates and default levels do not.
